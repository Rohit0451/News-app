export interface User {
  email: string;
  displayName: string;
  token: string;
  roles: string[];
}